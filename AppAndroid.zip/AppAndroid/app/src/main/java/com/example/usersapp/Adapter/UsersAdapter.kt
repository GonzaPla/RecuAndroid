package com.farhan.easyresto.Adapters

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.usersapp.Model.User
import com.example.usersapp.R
import com.example.usersapp.UserDetailActivity
import com.example.usersapp.databinding.NameItemListBinding
import com.google.gson.Gson

class UsersAdapter(var context: Context, var aryList: List<User>) :

    RecyclerView.Adapter<UsersAdapter.VH>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val view: View =
            LayoutInflater.from(parent.context)
                .inflate(R.layout.name_item_list, parent, false)
        return VH(view)
    }

    override fun onBindViewHolder(holder: UsersAdapter.VH, position: Int) {

        holder.binding.name.text = aryList[position].firstName + " " + aryList[position].lastName
        try {
            Glide.with(context).load(aryList[position].image).into(holder.binding.image)
        } catch (e: Exception) {
            e.printStackTrace()
        }



        holder.itemView.setOnClickListener {
            val intent = Intent(context, UserDetailActivity::class.java)
            intent.putExtra("data", Gson().toJson(aryList[position]))
            context.startActivity(intent)
        }


    }

    override fun getItemCount(): Int {
        return aryList.size
    }

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val binding = NameItemListBinding.bind(itemView)
    }


}
