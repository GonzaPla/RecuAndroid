package com.example.usersapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.bumptech.glide.Glide
import com.example.usersapp.Model.User
import com.example.usersapp.databinding.ActivityMainBinding
import com.example.usersapp.databinding.ActivityUserDetailBinding
import com.google.gson.Gson

class UserDetailActivity : AppCompatActivity() {

    var context = this
    lateinit var bin: ActivityUserDetailBinding
    lateinit var user: User

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bin = ActivityUserDetailBinding.inflate(layoutInflater)
        setContentView(bin.root)

        user = Gson().fromJson(intent.getStringExtra("data").toString(), User::class.java)

        setData()

        clickListener()


    }

    private fun setData() {
        bin.nameid.text = user.firstName +" "+ user.lastName
        bin.companyName.text = user.company.name
        bin.deptName.text = user.company.department
        bin.addName.text = user.company.address.address+" "+ user.company.address.city+", "+ user.company.address.state
        Glide.with(context).load(user.image).into(bin.cirimgid)
    }

    private fun clickListener() {
        bin.icBack.setOnClickListener {
            onBackPressed()
        }
    }
}