package com.example.usersapp.Model

data class User(
    var firstName: String = "",
    var lastName: String = "",
    var image: String = "",
    var company: Company
)