package com.example.usersapp.Model

data class Company(
    val name: String,
    val address: Address,
    val department: String,
    val title: String
)