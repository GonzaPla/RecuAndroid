package com.example.usersapp

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Response
import com.android.volley.VolleyError
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.usersapp.Model.User
import com.example.usersapp.Utils.LoadingDialog
import com.example.usersapp.databinding.ActivityMainBinding
import com.farhan.easyresto.Adapters.UsersAdapter
import com.google.gson.Gson
import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import org.json.JSONException

class MainActivity : AppCompatActivity() {

    lateinit var bin: ActivityMainBinding
    var context = this

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bin = ActivityMainBinding.inflate(layoutInflater)
        setContentView(bin.root)

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

        getUsersList()


    }

    private fun getUsersList() {
        val loadingDialog = LoadingDialog(context, "Processing...")
        loadingDialog.show()

        val rq = Volley.newRequestQueue(this)

        val request: StringRequest = object : StringRequest(
            Method.GET,
            "https://dummyjson.com/users",
            Response.Listener
            { response: String? ->
                try {
                    val gson = Gson()
                    val jsonObject = gson.fromJson(response, JsonObject::class.java)
                    val usersJsonArray = jsonObject.getAsJsonArray("users")

                    val userListType = object : TypeToken<List<User>>() {}.type
                    val userList: List<User> = gson.fromJson(usersJsonArray, userListType)

                    val adapter = UsersAdapter(context, userList)
                    bin.recycler.adapter = adapter

                    loadingDialog.dismiss()


                } catch (e: JSONException) {
                    loadingDialog.dismiss()
                    Toast.makeText(
                        context,
                        "Catch Error: " + e.message,
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            Response.ErrorListener { error: VolleyError ->
                loadingDialog.dismiss()
                Toast.makeText(
                    context,
                    "Error: " + error.message,
                    Toast.LENGTH_SHORT
                ).show()
            }) {
            override fun getParams(): Map<String, String>? {
                val map: MutableMap<String, String> = HashMap()
                return map
            }
        }
        request.retryPolicy = DefaultRetryPolicy(
            0,
            1,
            1f
        )
        rq.add(request)

    }


}